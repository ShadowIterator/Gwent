# gwent_resources
some resources for writting gwent
